# profit-forecast（利润预测 skill）

把 `E:\deskdowlond\利润预测工具.html` 里的计算内核抽成 AI skill：保留原页面的公式、默认参数与可行性规则，去掉 UI，并扩展为三种能力。

| 能力 | 输入 | 输出 |
|---|---|---|
| 正向 | 售价 + 目标利润率 | 最大采购价、利润、盈亏平衡价、可行性 |
| 反算 | 售价 + 实际采购价 | 实际利润/利润率、达标差额、达标所需售价 |
| 敏感性 | 售价区间 × 利润率区间 | 最大采购价矩阵（Markdown 表格） |

## 目录

```
profit-forecast/
├── SKILL.md                 # 技能定义（frontmatter + 何时用/怎么用/怎么讲）
├── README.md                # 本文件
├── scripts/
│   └── profit_calc.py       # 唯一计算入口（纯标准库，Python 3.9+）
├── references/
│   └── formula.md           # 公式推导、边界规则、展示口径、对拍说明
└── tests/
    ├── test_profit_calc.py  # 19 个单元测试（不依赖原 HTML）
    ├── parity_html.mjs      # 用页面自己的 calc() 生成对拍用例
    └── check_parity.py      # 与页面结果逐项比较
```

## 安装

本会话已装到项目技能目录：

```
<workspace>\.dsh\skills\profit-forecast\
```

DSH 会扫描项目根（最近的 `.git` 祖先；没有 `.git` 时就是当前工作目录）下的 `.dsh/skills`，技能目录必须是该根的直接子目录，嵌套的 `SKILL.md` 不会被发现；`name` 必须是 kebab-case，`description` 必填。装好后目录里出现 `profit-forecast` 即表示被识别（本会话技能目录已能看到它）。

DSH 的扫描优先级（由高到低）：

| 优先级 | 路径 |
|---|---|
| 100 | `<projectRoot>/.dsh/skills` |
| 200 | `<projectRoot>/.agents/skills` |
| 300 | `Config.customSkillDirs` |
| 400 | `<dshHome>/skills`（本机 `C:\Users\admin\.dsh\skills`） |
| 500 | `<agentsHome>/skills` |

其他环境：

- Claude Code：`~/.claude/skills/profit-forecast/`
- 其他兼容 Agent Skills 的运行时：放入其 skills 根目录即可，`SKILL.md` + `scripts/` 是通用结构。

建议安装后重启/新开会话，再用一句「售价 2 万韩元，目标利润率 20%，最多能出多少采购价」验证是否被加载。分发可用的压缩包：`profit-forecast.zip`。

## 快速验证

```powershell
# 正向（默认参数下应为 最大采购价 ₩6,840 / 利润 ₩4,000 / ¥33.37 / ¥19.51）
python scripts/profit_calc.py price=20000

# 反算
python scripts/profit_calc.py mode=reverse price=20000 procurement=8000

# 敏感性表
python scripts/profit_calc.py mode=sensitivity price=20000
```

`--json '{"price": 20000}'` 也可用（bash/macOS 没问题；Windows PowerShell 5.1 会吞掉双引号，所以文档统一用 `key=value`）。

## 测试

```powershell
python tests/test_profit_calc.py                       # 19 个单元测试
node tests/parity_html.mjs                             # 生成对拍用例（需要原 HTML）
python tests/check_parity.py                           # 与页面逐项比较
```

对拍默认读取 `E:\deskdowlond\利润预测工具.html`，换机器时用 `--html <路径>` 或环境变量 `HTML_PATH` 指定；找不到页面会自动 SKIP。

## 参数

| 字段 | 含义 | 默认值 |
|---|---|---|
| `price` | 售价（韩元） | 必填 |
| `commission_pct` | 平台佣金（%） | 10.8 |
| `vat_pct` | 税金 / VAT（%） | 10 |
| `return_pct` | 退货率（%） | 5 |
| `front_logistics` | 前端物流（韩元） | 1,000 |
| `back_logistics` | 后端物流（韩元） | 3,000 |
| `fx` | 汇率（韩元/人民币） | 205 |
| `target_margin_pct` | 目标利润率（%） | 20 |
| `procurement` | 实际采购价（韩元，reverse 必填） | — |
| `prices` / `margins` | 敏感性表坐标轴 | — |

## 设计说明

- **只搬公式，不搬 UI**：页面里的输入清洗、警告条、卡片布局对 agent 没有价值；计算内核和默认参数才是可复用资产。
- **确定性优先**：模型不做算术，脚本 JSON 进 JSON 出，`display` 字段给定最终展示串，避免同一问题两次回答格式不同。
- **默认值要显式**：`defaulted` 字段列出本次被默认的参数，skill 要求回答里写明假设。
- **汇率是入参**：默认 205，但不写死、不查实时汇率，保证结果可复现。
- **反算与敏感性是增量价值**：原页面只能「售价 → 采购价」，实际业务更常问「这个采购价利润多少」和「不同售价/利润率怎么取舍」。

## 已知边界

- 不处理多币种（除韩元/人民币）、不含平台费率分档、不含广告费/仓储费等其他成本项；需要时在 `_math()` 里加项并同步 `references/formula.md`。
- 百分比按「售价 × 百分比」计，与页面一致；若业务改为「按采购价计提佣金」，公式需重推。
