#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""利润预测内核（韩元口径）。

三种模式：
  forward      售价 -> 目标利润率下的最大采购价、利润、可行性（原 HTML 工具的能力）
  reverse      已知采购价 -> 实际利润/利润率、达标差距、达标所需售价
  sensitivity  售价 × 目标利润率 -> 最大采购价矩阵（Markdown 表格）

输入为 JSON，缺省参数使用页面默认值，并在 defaulted 中列出被默认的字段。
输出为 JSON；参数错误时输出 {"ok": false, "error": ...} 并以退出码 2 结束。

用法（推荐 key=value 形式，Windows PowerShell 下也不会被引号转义问题影响）：
  python profit_calc.py price=20000
  python profit_calc.py mode=reverse price=20000 procurement=6840
  python profit_calc.py mode=sensitivity price=20000
  python profit_calc.py mode=sensitivity prices=16000,18000,20000 margins=10,15,20
  python profit_calc.py --json '{"price": 20000}'
  python profit_calc.py --file params.json
"""

from __future__ import annotations

import argparse
import json
import math
import sys

# 与原 HTML 工具完全一致的默认参数（页面默认值）
DEFAULTS = {
    "price": 20000.0,            # 售价（韩元）
    "commission_pct": 10.8,      # 平台佣金（%）
    "vat_pct": 10.0,             # 税金 / VAT（%）
    "return_pct": 5.0,           # 退货率（%）
    "front_logistics": 1000.0,   # 前端物流（韩元）
    "back_logistics": 3000.0,    # 后端物流（韩元）
    "fx": 205.0,                 # 汇率（韩元 / 人民币）
    "target_margin_pct": 20.0,   # 目标利润率（%）
}

BASE_FIELDS = tuple(DEFAULTS)
ALLOWED = {
    "forward": set(BASE_FIELDS) | {"mode"},
    "reverse": set(BASE_FIELDS) | {"mode", "procurement"},
    "sensitivity": set(BASE_FIELDS) | {"mode", "prices", "margins"},
}
DEFAULT_MARGINS = [10.0, 15.0, 20.0, 25.0, 30.0]
PRICE_FACTORS = (0.8, 0.9, 1.0, 1.1, 1.2)
MAX_TABLE_SIZE = 20


# ---------------------------------------------------------------- 数值与格式

def _number(value, name):
    """把 JSON 里的数值/数字字符串转成有限 float；拒绝 bool。"""
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{name} 必须是数值")
    if isinstance(value, (int, float)):
        x = float(value)
    elif isinstance(value, str):
        try:
            x = float(value.strip())
        except ValueError:
            raise ValueError(f"{name} 必须是数值，收到 {value!r}") from None
    else:
        raise ValueError(f"{name} 必须是数值，收到 {type(value).__name__}")
    if not math.isfinite(x):
        raise ValueError(f"{name} 必须是有限数值")
    return x


def jround(x):
    """与 JS Math.round 一致（.5 向 +∞ 取整），仅用于展示层。"""
    return math.floor(x + 0.5)


def fmt_krw(x):
    n = jround(x)
    return f"-₩{abs(n):,}" if n < 0 else f"₩{n:,}"


def fmt_cny(x):
    return f"-¥{abs(x):,.2f}" if x < 0 else f"¥{x:,.2f}"


def fmt_both(krw, fx):
    return f"{fmt_krw(krw)}（≈{fmt_cny(krw / fx)}）"


def fmt_num(x):
    return f"{x:,.0f}" if abs(x - round(x)) < 1e-9 else f"{x:,.2f}"


# ---------------------------------------------------------------- 校验

def _validate_base(p):
    if p["price"] <= 0:
        raise ValueError("price（售价）必须 > 0")
    if p["fx"] <= 0:
        raise ValueError("fx（汇率）必须 > 0")


def load_params(raw, mode, require_price=True):
    """校验并补齐参数；返回 (params, defaulted)。"""
    if not isinstance(raw, dict):
        raise ValueError("输入必须是 JSON 对象")
    unknown = sorted(k for k in raw if k not in ALLOWED[mode])
    if unknown:
        allowed = ", ".join(sorted(ALLOWED[mode] - {"mode"}))
        raise ValueError(f"未知参数 {unknown}；可用参数：{allowed}")

    params, defaulted = {}, []
    for key in BASE_FIELDS:
        if key in raw:
            params[key] = _number(raw[key], key)
        elif key == "price" and require_price:
            raise ValueError("缺少 price（售价，韩元）")
        else:
            params[key] = DEFAULTS[key]
            defaulted.append(key)
    _validate_base(params)
    return params, defaulted


# ---------------------------------------------------------------- 计算内核

def _math(p):
    """纯韩元口径的中间量，不做任何取整。"""
    price, fx = p["price"], p["fx"]
    comm = p["commission_pct"] / 100
    vat = p["vat_pct"] / 100
    ret = p["return_pct"] / 100
    margin = p["target_margin_pct"] / 100
    fixed = p["front_logistics"] + p["back_logistics"]
    c_comm, c_vat, c_ret = price * comm, price * vat, price * ret
    profit = price * margin
    max_proc = price - c_comm - c_vat - c_ret - fixed - profit
    breakeven = price - c_comm - c_vat - c_ret - fixed
    return {
        "price": price, "fx": fx,
        "commission": comm, "vat": vat, "return_rate": ret,
        "target_margin": margin, "fixed": fixed,
        "c_comm": c_comm, "c_vat": c_vat, "c_ret": c_ret,
        "profit": profit, "max_proc": max_proc, "breakeven": breakeven,
        "margin_pct": profit / price * 100,
        "cost_ratio": comm + vat + ret + margin,
    }


def _clean(value):
    """输出前收敛浮点噪声（6 位小数），避免 2160.0000000000005 这类值进入上下文。"""
    if isinstance(value, float):
        rounded = round(value, 6)
        return 0.0 if rounded == 0 else rounded
    if isinstance(value, dict):
        return {k: _clean(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean(v) for v in value]
    return value


def _forward_payload(p, defaulted):
    m = _math(p)
    P, fx = m["price"], m["fx"]
    feasible = m["max_proc"] > 0
    notes = []

    if not feasible:
        if m["cost_ratio"] >= 1:
            notes.append("佣金 + 税金 + 退货率 + 目标利润率合计 ≥ 100%，任何售价都不可能有正的采购价。")
        else:
            min_price = m["fixed"] / (1 - m["cost_ratio"])
            notes.append(
                f"目标利润率 {p['target_margin_pct']:.1f}% 下，售价需高于 {fmt_both(min_price, fx)}"
                f"才能给出正的采购价（当前 {fmt_both(P, fx)}）。"
            )
        max_margin = (1 - m["commission"] - m["vat"] - m["return_rate"] - m["fixed"] / P) * 100
        notes.append(
            f"该售价的盈亏平衡采购价（利润 = 0）为 {fmt_both(m['breakeven'], fx)}；"
            f"该售价下利润率需低于 {max_margin:.1f}%。"
        )

    formula = (
        "最大采购价 = 售价×(1 − "
        + " − ".join(f"{v * 100:.1f}%" for v in
                     (m["commission"], m["vat"], m["return_rate"], m["target_margin"]))
        + f") − {fmt_num(p['front_logistics'])} − {fmt_num(p['back_logistics'])}"
        + f" = {fmt_krw(m['max_proc'])}；利润 = 售价 × {m['target_margin'] * 100:.1f}% = {fmt_krw(m['profit'])}"
    )

    return {
        "ok": True,
        "mode": "forward",
        "input": _echo_input(p),
        "defaulted": defaulted,
        "krw": {
            "price": P,
            "commission": m["c_comm"],
            "vat": m["c_vat"],
            "return_fee": m["c_ret"],
            "front_logistics": p["front_logistics"],
            "back_logistics": p["back_logistics"],
            "profit": m["profit"],
            "max_procurement": m["max_proc"],
            "breakeven_procurement": m["breakeven"],
            "margin_pct": m["margin_pct"],
        },
        "cny": {
            "price": P / fx,
            "profit": m["profit"] / fx,
            "max_procurement": m["max_proc"] / fx,
            "breakeven_procurement": m["breakeven"] / fx,
        },
        "feasible": feasible,
        "display": {
            "price": fmt_both(P, fx),
            "max_procurement": fmt_both(m["max_proc"], fx),
            "breakeven_procurement": fmt_both(m["breakeven"], fx),
            "profit": fmt_both(m["profit"], fx),
            "margin": f"{m['margin_pct']:.1f}%",
        },
        "formula": formula,
        "notes": notes,
    }


def _echo_input(p):
    return {
        "price": p["price"],
        "commission_pct": p["commission_pct"],
        "vat_pct": p["vat_pct"],
        "return_pct": p["return_pct"],
        "front_logistics": p["front_logistics"],
        "back_logistics": p["back_logistics"],
        "fx": p["fx"],
        "target_margin_pct": p["target_margin_pct"],
        **({"procurement": p["procurement"]} if "procurement" in p else {}),
    }


def calc_forward(p, defaulted):
    return _forward_payload(p, defaulted)


def calc_reverse(p, defaulted):
    m = _math(p)
    P, fx, C = m["price"], m["fx"], p["procurement"]
    profit = P - C - m["c_comm"] - m["c_vat"] - m["c_ret"] - m["fixed"]
    margin_pct = profit / P * 100
    target_pct = p["target_margin_pct"]
    meets = margin_pct >= target_pct - 1e-9
    gap = C - m["max_proc"]          # > 0 表示采购价超出目标利润率允许的上限
    denom = 1 - m["cost_ratio"]
    required_price = (C + m["fixed"]) / denom if denom > 0 else None

    notes = []
    if profit < 0:
        notes.append(f"当前采购价已导致亏损：利润 {fmt_both(profit, fx)}。")
    if meets:
        headroom = m["max_proc"] - C
        if abs(headroom) < 0.5:
            notes.append(
                f"实际利润率 {margin_pct:.1f}% 刚好卡在目标 {target_pct:.1f}% 的上限"
                f"（采购价上限 {fmt_both(m['max_proc'], fx)}）。"
            )
        else:
            notes.append(
                f"实际利润率 {margin_pct:.1f}% 达标（目标 {target_pct:.1f}%）；"
                f"采购价上限 {fmt_both(m['max_proc'], fx)}，当前 {fmt_both(C, fx)}，"
                f"仍有 {fmt_both(headroom, fx)} 空间。"
            )
    else:
        msg = (
            f"实际利润率 {margin_pct:.1f}% 低于目标 {target_pct:.1f}%。"
            f"要达标：采购价需 ≤ {fmt_both(m['max_proc'], fx)}（当前高 {fmt_both(gap, fx)}）"
        )
        if required_price is not None:
            msg += f"，或售价需 ≥ {fmt_both(required_price, fx)}（当前 {fmt_both(P, fx)}）。"
        else:
            msg += "；且佣金 + 税金 + 退货率 + 目标利润率 ≥ 100%，任何售价都无法达标。"
        notes.append(msg)

    return {
        "ok": True,
        "mode": "reverse",
        "input": _echo_input(p),
        "defaulted": defaulted,
        "krw": {
            "price": P,
            "procurement": C,
            "profit": profit,
            "margin_pct": margin_pct,
            "target_margin_pct": target_pct,
            "max_procurement_at_target": m["max_proc"],
            "breakeven_procurement": m["breakeven"],
            "over_budget": gap,
            "required_price_at_target": required_price,
        },
        "cny": {
            "profit": profit / fx,
            "max_procurement_at_target": m["max_proc"] / fx,
            "over_budget": gap / fx,
            "required_price_at_target": required_price / fx if required_price is not None else None,
        },
        "feasible": profit > 0,
        "meets_target": meets,
        "display": {
            "profit": fmt_both(profit, fx),
            "margin": f"{margin_pct:.1f}%",
            "target_margin": f"{target_pct:.1f}%",
            "max_procurement_at_target": fmt_both(m["max_proc"], fx),
            "over_budget": fmt_both(gap, fx),
            "required_price_at_target": (
                fmt_both(required_price, fx) if required_price is not None else None
            ),
        },
        "notes": notes,
    }


def _derive_prices(base_price):
    return [jround(base_price * f / 100) * 100 for f in PRICE_FACTORS]


def _number_list(value, name):
    if not isinstance(value, list) or not value:
        raise ValueError(f"{name} 必须是非空数值数组")
    if len(value) > MAX_TABLE_SIZE:
        raise ValueError(f"{name} 最多 {MAX_TABLE_SIZE} 项（表格过宽没有意义）")
    return [_number(v, f"{name}[{i}]") for i, v in enumerate(value)]


def calc_sensitivity(p, defaulted, explicit_price):
    fx = p["fx"]
    prices = p.pop("prices", None)
    margins = p.pop("margins", None)
    if prices is not None:
        prices = _number_list(prices, "prices")
    elif explicit_price:
        prices = _derive_prices(p["price"])
    else:
        raise ValueError("sensitivity 需要提供 prices 数组，或提供基准 price 以自动生成价格区间")
    margins = DEFAULT_MARGINS if margins is None else _number_list(margins, "margins")
    for v in prices:
        if v <= 0:
            raise ValueError("prices 中的售价必须 > 0")

    cells, rows = [], []
    header = "| 售价 ₩ | " + " | ".join(f"{x:g}%" for x in margins) + " |"
    sep = "|---:|" + "---:|" * len(margins)
    rows.append(header)
    rows.append(sep)

    for price in prices:
        row = [f"{jround(price):,}"]
        for target in margins:
            q = dict(p, price=price, target_margin_pct=target)
            mm = _math(q)
            feasible = mm["max_proc"] > 0
            cells.append({
                "price": price,
                "target_margin_pct": target,
                "max_procurement": mm["max_proc"],
                "max_procurement_cny": mm["max_proc"] / fx,
                "profit": mm["profit"],
                "feasible": feasible,
            })
            cell = f"{fmt_krw(mm['max_proc'])}（{fmt_cny(mm['max_proc'] / fx)}）"
            row.append(cell if feasible else f"✗ {cell}")
        rows.append("| " + " | ".join(row) + " |")

    table = "\n".join(rows) + (
        f"\n\n> 单元格：最大采购价 ₩（≈¥，汇率 {fx:g}）；✗ 表示该目标利润率下不可行。"
    )

    return {
        "ok": True,
        "mode": "sensitivity",
        "input": {
            "prices": prices,
            "margins": margins,
            "commission_pct": p["commission_pct"],
            "vat_pct": p["vat_pct"],
            "return_pct": p["return_pct"],
            "front_logistics": p["front_logistics"],
            "back_logistics": p["back_logistics"],
            "fx": fx,
        },
        "defaulted": defaulted,
        "prices": prices,
        "margins": margins,
        "cells": cells,
        "table_markdown": table,
        "notes": [],
    }


# ---------------------------------------------------------------- CLI

def run(raw):
    if not isinstance(raw, dict):
        raise ValueError("输入必须是 JSON 对象")
    mode = raw.get("mode", "forward")
    if mode not in ALLOWED:
        raise ValueError(f"未知 mode {mode!r}；可用：forward、reverse、sensitivity")

    explicit_price = "price" in raw
    params, defaulted = load_params(
        raw, mode, require_price=(mode != "sensitivity") or explicit_price
    )

    if mode == "forward":
        return _clean(calc_forward(params, defaulted))
    if mode == "reverse":
        if "procurement" not in raw:
            raise ValueError("reverse 模式需要 procurement（实际采购价，韩元）")
        params["procurement"] = _number(raw["procurement"], "procurement")
        return _clean(calc_reverse(params, defaulted))

    if "prices" in raw:
        params["prices"] = raw["prices"]
    if "margins" in raw:
        params["margins"] = raw["margins"]
    elif "target_margin_pct" in raw:
        # 显式给了目标利润率、又没给 margins：按单列做表，避免参数被静默忽略
        params["margins"] = [params["target_margin_pct"]]
    if not explicit_price and "prices" not in raw:
        raise ValueError("sensitivity 需要提供 prices 数组，或提供基准 price")
    return _clean(calc_sensitivity(params, defaulted, explicit_price))


def _from_pairs(pairs):
    """把 key=value 命令行参数转成输入对象；prices/margins 用逗号分隔成数组。"""
    raw = {}
    for item in pairs:
        if "=" not in item:
            raise ValueError(f"参数应为 key=value 形式，收到 {item!r}")
        key, value = item.split("=", 1)
        key, value = key.strip(), value.strip()
        if key in ("prices", "margins"):
            raw[key] = [_number(part, key) for part in value.split(",") if part.strip()]
        elif key == "mode":
            raw[key] = value
        else:
            raw[key] = _number(value, key)
    return raw


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="利润预测内核（韩元口径）")
    ap.add_argument("pairs", nargs="*", help="key=value 参数，如 price=20000 mode=reverse procurement=6840")
    ap.add_argument("--json", default=None, help="JSON 字符串参数")
    ap.add_argument("--file", default=None, help="从文件读取 JSON 参数")
    args = ap.parse_args(argv)

    sources = [name for name, used in
               (("--file", args.file), ("--json", args.json), ("key=value", args.pairs)) if used]
    if len(sources) > 1:
        print(json.dumps({"ok": False, "error": f"参数来源只能选一种，收到：{' / '.join(sources)}"},
                         ensure_ascii=False, indent=2))
        return 2

    try:
        if args.file:
            # utf-8-sig：兼容记事本 / PowerShell 写出的带 BOM 文件
            with open(args.file, "r", encoding="utf-8-sig") as fh:
                raw = json.load(fh)
        elif args.json:
            raw = json.loads(args.json)
        else:
            raw = _from_pairs(args.pairs)
        result = run(raw)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
