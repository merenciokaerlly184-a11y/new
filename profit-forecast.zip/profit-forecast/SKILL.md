---
name: profit-forecast
description: "Forecast profit for Korean e-commerce (KRW prices): compute the maximum procurement price from a selling price at a target margin, reverse-solve actual profit and margin from a known procurement cost, and build price × margin sensitivity tables. Handles commission, VAT, return rate, front/back logistics, and FX rate. Use for 利润预测、最大采购价、反算利润率、采购价反算、售价测算、敏感性分析、韩元定价."
---

# 利润预测（韩元口径）

## 何时使用

- 用户给韩元售价，问「最多能出多少采购价」「利润多少」「这个售价能不能做」→ `forward`
- 用户给采购价，问「利润/利润率多少」「要达标该卖多少钱」→ `reverse`
- 用户要「不同售价 × 不同目标利润率」的对照表 → `sensitivity`
- 比价、报价、选品测算、目标利润率反推

不适用：单纯汇率换算、会计记账、平台后台取数。

## 铁律

1. **不手算、不自行推导公式**：所有数字必须由 `scripts/profit_calc.py` 产出。
2. 用户没给的参数用默认值，但回答里必须写明「本次假设」。
3. **结论先行**：先给最大采购价 / 利润 / 利润率，再给拆解。
4. 命令用 `key=value` 传参（Windows PowerShell 下 `--json` 的引号会被吞掉，不要用）。
5. 展示金额直接用输出里的 `display` 字段，不要自己重算或重新格式化。

## 命令

脚本路径：`<skill 目录>/scripts/profit_calc.py`（与本文件同级）。下面用 `$SKILL` 代表该目录的绝对路径，先设一次（bash 用 `SKILL=/path/to/profit-forecast`）：

```powershell
$SKILL = "C:\path\to\profit-forecast"   # 换成实际安装路径

# 正向：售价 -> 最大采购价（其余参数省略即用默认值）
python "$SKILL/scripts/profit_calc.py" price=20000

# 正向：带全部参数
python "$SKILL/scripts/profit_calc.py" price=20000 commission_pct=10.8 vat_pct=10 return_pct=5 front_logistics=1000 back_logistics=3000 fx=205 target_margin_pct=20

# 反算：已知售价与采购价 -> 实际利润/利润率/是否达标/达标所需售价
python "$SKILL/scripts/profit_calc.py" mode=reverse price=20000 procurement=6840

# 敏感性表：基准售价自动生成 16k/18k/20k/22k/24k × 10/15/20/25/30%
python "$SKILL/scripts/profit_calc.py" mode=sensitivity price=20000

# 敏感性表：自定义坐标轴
python "$SKILL/scripts/profit_calc.py" mode=sensitivity prices=16000,18000,20000,22000,24000 margins=10,15,20,25,30
```

复杂输入可写成 JSON 文件再 `--file params.json`，字段名与参数名一致。不知道安装路径时，先用文件搜索定位 `profit_calc.py`。

## 参数

| 字段 | 含义 | 单位 | 默认值 |
|---|---|---|---|
| `price` | 售价（正向/反算必填） | 韩元 | — |
| `commission_pct` | 平台佣金 | % | 10.8 |
| `vat_pct` | 税金 / VAT | % | 10 |
| `return_pct` | 退货率 | % | 5 |
| `front_logistics` | 前端物流 | 韩元 | 1,000 |
| `back_logistics` | 后端物流 | 韩元 | 3,000 |
| `fx` | 汇率（韩元/人民币） | — | 205 |
| `target_margin_pct` | 目标利润率 | % | 20 |
| `procurement` | 实际采购价（`reverse` 必填） | 韩元 | — |
| `prices` / `margins` | 敏感性表坐标轴（`sensitivity` 可选） | 数组 | 见上 |

百分比一律传数字（`10.8`），不要传 `"10.8%"`。

## 输出怎么讲

### forward
> 按售价 ₩20,000、目标利润率 20%：最大采购价 **₩6,840（≈¥33.37）**，利润 **₩4,000（≈¥19.51）**，利润率 20%，可行。
>
> 拆解：售价 ₩20,000 − 佣金 ₩2,160 − VAT ₩2,000 − 退货费 ₩1,000 − 前端物流 ₩1,000 − 后端物流 ₩3,000 − 利润 ₩4,000 = 采购价 ₩6,840。
>
> 假设：佣金 10.8%、VAT 10%、退货 5%、汇率 205（用户未指定）。

### reverse
> 售价 ₩20,000、采购价 ₩8,000：利润 ₩2,840（≈¥13.85），利润率 14.2%，**低于**目标 20%。要达标，采购价需 ≤ ₩6,840（当前高 ₩1,160），或售价需 ≥ ₩22,140。

### sensitivity
直接贴输出的 `table_markdown`，补一句：
> 表格单元格为该售价 / 目标利润率下的最大采购价（韩元，括号内为按汇率 205 折算的人民币）；✗ 表示不可行。

若用户只问「哪个售价/利润率组合更合适」，基于表给 1–2 句结论（如「售价 18,000 以下、目标 25% 以上已不可行」），不要长篇罗列。

## 可行性判断（重要）

- `feasible=false`（最大采购价 ≤ 0）时不要只报「算不了」：说明**目标利润率在该售价下不成立**，给盈亏平衡采购价，并按 `notes` 给出「降价或提价」的具体数字建议。
- 采购价高于上限但仍有利润（`reverse` 中 `meets_target=false`、`feasible=true`）：正常给数，附「差多少」和两种补救路径（压采购价 / 提售价）。

## 异常处理

- 退出码 2 且 `ok=false`：把 `error` 原文告诉用户，请其确认参数后重跑。
- 缺参：`forward`/`reverse` 必须有 `price`，`reverse` 还必须有 `procurement`；`sensitivity` 需要 `price` 或 `prices`。
- 未知字段会直接报错（避免拼错字段名后静默使用默认值）；按报错列出的可用字段修正。
- 不要为了防止报错而删掉用户给的参数。

## 口径

- 计算与结算口径均为**韩元**；人民币只是按 `fx` 折算的展示值。
- 韩元金额四舍五入到整数，人民币保留 2 位小数，均由脚本完成。
- `display` 字段已经是最终展示串，直接引用。
