/**
 * 与原 HTML 页面（E:\deskdowlond\利润预测工具.html）对拍。
 *
 * 做法：在 Node 的 vm 里搭一个极简 DOM，直接执行页面最后一个 <script>，
 * 调用页面自己的 calc()，读出 DOM 里的展示结果，写成 JSON 用例文件。
 * 再用 tests/check_parity.py 把它和 scripts/profit_calc.py 的结果逐项比较。
 *
 * 用法：
 *   node tests/parity_html.mjs --html "E:\deskdowlond\利润预测工具.html" --out tests/.parity_cases.json
 *   node tests/parity_html.mjs            # 默认路径 & 默认输出
 */

import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);

let htmlPath = process.env.HTML_PATH || 'E:\\deskdowlond\\利润预测工具.html';
let outPath = path.join(here, '.parity_cases.json');
for (let i = 0; i < argv.length; i += 1) {
  if (argv[i] === '--html') htmlPath = argv[++i];
  else if (argv[i] === '--out') outPath = argv[++i];
  else htmlPath = argv[i];
}

if (!fs.existsSync(htmlPath)) {
  console.log(JSON.stringify({ skipped: true, reason: `找不到原页面：${htmlPath}` }, null, 2));
  process.exit(0);
}

// ---- 极简 DOM：页面用到的 getElementById / value / textContent / innerHTML / style / addEventListener
const elements = new Map();
function element(id) {
  if (!elements.has(id)) {
    elements.set(id, {
      id, value: '', textContent: '', innerHTML: '', style: {},
      addEventListener() {},
    });
  }
  return elements.get(id);
}
const document = { getElementById: element };

const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
if (scripts.length === 0) {
  console.error(`页面里没有找到 <script>：${htmlPath}`);
  process.exit(1);
}

const ctx = vm.createContext({ document, console });
vm.runInContext(scripts[scripts.length - 1][1], ctx);
if (typeof ctx.calc !== 'function') {
  console.error('页面脚本没有暴露 calc()，无法对拍。');
  process.exit(1);
}

function setInputs(v) {
  element('price').value = String(v.price);
  element('comm').value = String(v.commission_pct);
  element('vat').value = String(v.vat_pct);
  element('ret').value = String(v.return_pct);
  element('front').value = String(v.front_logistics);
  element('back').value = String(v.back_logistics);
  element('rate').value = String(v.fx);
  element('margin').value = String(v.target_margin_pct);
  ctx.calc();
}

/** 从 "−₩6,840 （¥33.37）" 这样的展示串里取数字 */
function parseCurrency(text, symbol) {
  const cleaned = String(text).replace(/,/g, '');
  const match = cleaned.match(new RegExp(`${symbol}\\s*(-?\\d+(?:\\.\\d+)?)`));
  return match ? Number(match[1]) : null;
}

function snapshot(v) {
  setInputs(v);
  const proc = element('rProc').innerHTML;
  const profit = element('rProfit').innerHTML;
  return {
    input: { ...v },
    page: {
      proc_krw: parseCurrency(proc, '₩'),
      proc_cny: parseCurrency(proc, '¥'),
      profit_krw: parseCurrency(profit, '₩'),
      profit_cny: parseCurrency(profit, '¥'),
    },
  };
}

// ---- 用例：3 个黄金用例 + 30 个随机用例（固定种子，结果可复现）
const golden = [
  { price: 20000, commission_pct: 10.8, vat_pct: 10, return_pct: 5,
    front_logistics: 1000, back_logistics: 3000, fx: 205, target_margin_pct: 20 },
  { price: 5000, commission_pct: 10.8, vat_pct: 10, return_pct: 5,
    front_logistics: 1000, back_logistics: 3000, fx: 205, target_margin_pct: 20 },
  { price: 20000, commission_pct: 20, vat_pct: 10, return_pct: 5,
    front_logistics: 1000, back_logistics: 3000, fx: 205, target_margin_pct: 20 },
];

function mulberry32(seed) {
  let a = seed;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(42);
const pick = (min, max, digits = 0) => {
  const value = min + rand() * (max - min);
  return digits === 0 ? Math.round(value) : Number(value.toFixed(digits));
};

const random = Array.from({ length: 30 }, () => ({
  price: pick(3000, 60000),
  commission_pct: pick(0, 30, 1),
  vat_pct: pick(0, 20, 1),
  return_pct: pick(0, 15, 1),
  front_logistics: pick(0, 3000),
  back_logistics: pick(0, 5000),
  fx: pick(150, 260),
  target_margin_pct: pick(0, 40, 1),
}));

const cases = [...golden, ...random].map(snapshot);
const invalid = cases.filter((c) => Object.values(c.page).some((x) => x === null || Number.isNaN(x)));
if (invalid.length > 0) {
  console.error(`有 ${invalid.length} 个用例没能从页面读出数字，例如：`, invalid[0]);
  process.exit(1);
}

const payload = {
  html: htmlPath,
  generated_at: new Date().toISOString(),
  cases,
};
fs.writeFileSync(outPath, JSON.stringify(payload, null, 2), 'utf8');
console.log(`对拍用例已写入 ${outPath}（${cases.length} 条）`);
