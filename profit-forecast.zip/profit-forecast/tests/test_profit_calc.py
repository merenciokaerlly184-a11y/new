#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""profit_calc 的单元测试（不依赖网络、不依赖原 HTML）。

运行：
  python tests/test_profit_calc.py
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import profit_calc as pc  # noqa: E402


class ForwardTests(unittest.TestCase):
    def test_default_matches_original_page(self):
        r = pc.run({"price": 20000})
        self.assertTrue(r["ok"])
        self.assertEqual(r["mode"], "forward")
        self.assertAlmostEqual(r["krw"]["max_procurement"], 6840.0)
        self.assertAlmostEqual(r["krw"]["profit"], 4000.0)
        self.assertAlmostEqual(r["krw"]["breakeven_procurement"], 10840.0)
        self.assertAlmostEqual(r["krw"]["commission"], 2160.0)
        self.assertAlmostEqual(r["krw"]["margin_pct"], 20.0)
        self.assertTrue(r["feasible"])
        self.assertEqual(r["display"]["max_procurement"], "₩6,840（≈¥33.37）")
        self.assertEqual(r["display"]["profit"], "₩4,000（≈¥19.51）")
        self.assertEqual(r["display"]["margin"], "20.0%")

    def test_defaulted_fields_reported(self):
        r = pc.run({"price": 20000})
        self.assertEqual(
            set(r["defaulted"]),
            {"commission_pct", "vat_pct", "return_pct", "front_logistics",
             "back_logistics", "fx", "target_margin_pct"},
        )
        r2 = pc.run({"price": 20000, "commission_pct": 10.8})
        self.assertNotIn("commission_pct", r2["defaulted"])

    def test_infeasible_price(self):
        r = pc.run({"price": 5000})
        self.assertAlmostEqual(r["krw"]["max_procurement"], -1290.0)
        self.assertAlmostEqual(r["krw"]["breakeven_procurement"], -290.0)
        self.assertFalse(r["feasible"])
        self.assertTrue(any("盈亏平衡" in n for n in r["notes"]))
        self.assertTrue(r["display"]["max_procurement"].startswith("-₩1,290"))

    def test_high_commission(self):
        r = pc.run({"price": 20000, "commission_pct": 20})
        self.assertAlmostEqual(r["krw"]["max_procurement"], 5000.0)

    def test_fx_is_input(self):
        r = pc.run({"price": 20000, "fx": 100})
        self.assertAlmostEqual(r["cny"]["max_procurement"], 68.4)
        r2 = pc.run({"price": 20000, "fx": 200})
        self.assertAlmostEqual(r2["cny"]["max_procurement"], 34.2)

    def test_percent_string_not_accepted(self):
        with self.assertRaises(ValueError):
            pc.run({"price": "20000", "commission_pct": "10.8%"})

    def test_missing_price(self):
        with self.assertRaises(ValueError):
            pc.run({})

    def test_unknown_key_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            pc.run({"price": 20000, "commision_pct": 10})
        self.assertIn("未知参数", str(ctx.exception))

    def test_bad_numbers_rejected(self):
        for bad in ({"price": 0}, {"price": -1}, {"price": 20000, "fx": 0},
                    {"price": 20000, "fx": True}, {"price": "abc"}):
            with self.assertRaises(ValueError):
                pc.run(bad)


class ReverseTests(unittest.TestCase):
    def test_exactly_at_target(self):
        r = pc.run({"mode": "reverse", "price": 20000, "procurement": 6840})
        self.assertAlmostEqual(r["krw"]["profit"], 4000.0)
        self.assertAlmostEqual(r["krw"]["margin_pct"], 20.0)
        self.assertTrue(r["meets_target"])
        self.assertAlmostEqual(r["krw"]["required_price_at_target"], 20000.0)
        self.assertAlmostEqual(r["krw"]["over_budget"], 0.0)

    def test_over_budget(self):
        r = pc.run({"mode": "reverse", "price": 20000, "procurement": 8000})
        self.assertAlmostEqual(r["krw"]["profit"], 2840.0)
        self.assertAlmostEqual(r["krw"]["margin_pct"], 14.2)
        self.assertFalse(r["meets_target"])
        self.assertAlmostEqual(r["krw"]["over_budget"], 1160.0)
        self.assertAlmostEqual(r["krw"]["required_price_at_target"], 22140.221402, places=5)
        self.assertIn("低于目标", r["notes"][0])

    def test_loss(self):
        r = pc.run({"mode": "reverse", "price": 20000, "procurement": 13000})
        self.assertAlmostEqual(r["krw"]["profit"], -2160.0)
        self.assertFalse(r["feasible"])
        self.assertTrue(any("亏损" in n for n in r["notes"]))

    def test_impossible_required_price(self):
        r = pc.run({"mode": "reverse", "price": 20000, "procurement": 8000,
                    "commission_pct": 50, "vat_pct": 30, "return_pct": 10,
                    "target_margin_pct": 20})
        self.assertIsNone(r["krw"]["required_price_at_target"])
        self.assertIsNone(r["display"]["required_price_at_target"])
        self.assertTrue(any("任何售价" in n for n in r["notes"]))

    def test_missing_procurement(self):
        with self.assertRaises(ValueError) as ctx:
            pc.run({"mode": "reverse", "price": 20000})
        self.assertIn("procurement", str(ctx.exception))


class SensitivityTests(unittest.TestCase):
    def test_default_shape_and_values(self):
        r = pc.run({"mode": "sensitivity", "price": 20000})
        self.assertEqual(r["prices"], [16000, 18000, 20000, 22000, 24000])
        self.assertEqual(r["margins"], [10.0, 15.0, 20.0, 25.0, 30.0])
        self.assertEqual(len(r["cells"]), 25)
        cell = next(c for c in r["cells"]
                    if c["price"] == 20000 and c["target_margin_pct"] == 20.0)
        self.assertAlmostEqual(cell["max_procurement"], 6840.0)
        lines = r["table_markdown"].splitlines()
        self.assertEqual(len(lines), 2 + 5 + 2)  # 表头 + 分隔 + 5 行 + 空行 + 注释
        self.assertIn("20,000", lines[4])

    def test_monotonic(self):
        r = pc.run({"mode": "sensitivity", "price": 20000})
        for price in r["prices"]:
            row = [c["max_procurement"] for c in r["cells"] if c["price"] == price]
            self.assertEqual(row, sorted(row, reverse=True))
        for margin in r["margins"]:
            col = [c["max_procurement"] for c in r["cells"]
                   if c["target_margin_pct"] == margin]
            self.assertEqual(col, sorted(col))

    def test_explicit_axes_and_infeasible_cell(self):
        r = pc.run({"mode": "sensitivity", "prices": [5000], "margins": [30]})
        self.assertEqual(r["prices"], [5000])
        self.assertFalse(r["cells"][0]["feasible"])
        self.assertIn("✗", r["table_markdown"])

    def test_needs_price_or_prices(self):
        with self.assertRaises(ValueError):
            pc.run({"mode": "sensitivity"})
        with self.assertRaises(ValueError):
            pc.run({"mode": "sensitivity", "prices": []})


class FormatTests(unittest.TestCase):
    def test_money_format(self):
        self.assertEqual(pc.fmt_krw(6840), "₩6,840")
        self.assertEqual(pc.fmt_krw(-1290), "-₩1,290")
        self.assertEqual(pc.fmt_cny(33.3658), "¥33.37")
        self.assertEqual(pc.fmt_cny(-6.29), "-¥6.29")
        self.assertEqual(pc.jround(0.5), 1)
        self.assertEqual(pc.jround(-0.5), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
