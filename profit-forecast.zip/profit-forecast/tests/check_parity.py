#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 page 对拍结果与 profit_calc 的结果逐项比较。

先运行 tests/parity_html.mjs 生成用例，再运行本脚本：
  node tests/parity_html.mjs
  python tests/check_parity.py

页面只展示取整后的金额，因此：
  - 韩元按页面展示口径取整后必须完全相等；
  - 人民币允许 0.011 的差异（页面 toFixed(2) 与 Python round 的边界差异）。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import profit_calc as pc  # noqa: E402

CASES = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "tests" / ".parity_cases.json"


def main() -> int:
    if not CASES.exists():
        print(f"SKIP：找不到对拍用例 {CASES}，先运行 node tests/parity_html.mjs")
        return 0

    payload = json.loads(CASES.read_text(encoding="utf-8"))
    if payload.get("skipped"):
        print(f"SKIP：{payload.get('reason')}")
        return 0

    cases = payload["cases"]
    failures = []
    for index, case in enumerate(cases):
        inp = case["input"]
        page = case["page"]
        result = pc.run(inp)
        krw = result["krw"]
        cny = result["cny"]

        checks = {
            "max_procurement_krw": (pc.jround(krw["max_procurement"]), page["proc_krw"], 0),
            "profit_krw": (pc.jround(krw["profit"]), page["profit_krw"], 0),
            "max_procurement_cny": (round(cny["max_procurement"], 2), page["proc_cny"], 0.011),
            "profit_cny": (round(cny["profit"], 2), page["profit_cny"], 0.011),
        }
        for name, (got, want, tol) in checks.items():
            if abs(got - want) > tol:
                failures.append(
                    f"#{index} {name}: page={want} skill={got} input={inp}"
                )

    if failures:
        print(f"FAIL：{len(failures)} 项不一致（共 {len(cases)} 条用例）")
        for line in failures[:20]:
            print("  -", line)
        return 1

    print(f"PASS：{len(cases)} 条用例与页面完全一致")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
